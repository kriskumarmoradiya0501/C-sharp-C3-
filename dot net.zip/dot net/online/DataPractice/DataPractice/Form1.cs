﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Http.Headers;

namespace DataPractice
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ADMIN\OneDrive\文档\Test.mdf;Integrated Security=True;Connect Timeout=30";
            //string connstring = @"Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\ADMIN\\OneDrive\\文档\\Test.mdf;Integrated Security=True;Connect Timeout=30";
            
            conn.ConnectionString = connstring;
            conn.Open();
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUser.Text))
            {
                MessageBox.Show("Enter Username...");
                txtUser.Focus();
                return; // Exit the method to prevent further execution
            }
            if (string.IsNullOrEmpty(txtPass.Text))
            {
                MessageBox.Show("Enter Password...");
                txtPass.Focus();
                return; // Exit the method to prevent further execution
            }

            string query = "SELECT * FROM login WHERE user = @user AND pass = @pass";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@user", txtUser.Text);
                cmd.Parameters.AddWithValue("@pass", txtPass.Text);

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        MessageBox.Show("Login successful..");
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password.");
                    }
                }
            }
        }


        private void btnReg_Click(object sender, EventArgs e)
        {
            string query;
            query = "Insert into Login (user,pass) values ('"+txtUser.Text+"','"+txtPass.Text+"')";
            MessageBox.Show(query);
            cmd.CommandText = query;
            cmd.Connection = conn;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Registration successfull...");
        }
    }
}
